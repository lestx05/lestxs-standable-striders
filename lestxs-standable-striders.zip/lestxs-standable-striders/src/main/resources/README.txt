Put your mod resources here (fabric.mod.json, mixins JSON, assets, etc.).
